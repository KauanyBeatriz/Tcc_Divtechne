

<?php $__env->startSection('title', 'ETEC EVENTOS'); ?>

<?php $__env->startSection('content'); ?>

        <h1>TELA DOS PRODUTOS </h1>
        
        <?php if($busca != ''): ?>
            <p> O usuário esta buscando produtos: <?php echo e($busca); ?></p>
            
        <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kauan\Downloads\etecevents\etecevents\resources\views/products.blade.php ENDPATH**/ ?>