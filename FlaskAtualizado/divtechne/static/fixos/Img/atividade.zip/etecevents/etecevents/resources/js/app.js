import './bootstrap';
console.log("Está funcionando")