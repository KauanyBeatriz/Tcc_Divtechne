@extends('layouts.main')

@section('title', 'Produto')

@section('content')

        <h1>Produtos exibindo id:{{ $id }}</h1>
        <br>

        @if ($id != null)
                <p>Exibindo produtos no if id:{{ $id }}</p>
            
        @endif
        
@endsection