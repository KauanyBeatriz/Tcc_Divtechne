

<?php $__env->startSection('title', 'Produto'); ?>

<?php $__env->startSection('content'); ?>

        <h1>Produtos exibindo id:<?php echo e($id); ?></h1>
        <br>

        <?php if($id != null): ?>
                <p>Exibindo produtos no if id:<?php echo e($id); ?></p>
            
        <?php endif; ?>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kauan\Downloads\etecevents\etecevents\resources\views/product.blade.php ENDPATH**/ ?>