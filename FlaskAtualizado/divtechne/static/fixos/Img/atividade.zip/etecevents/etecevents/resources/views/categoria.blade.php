@extends('layouts.main')

@section('title', 'Categoria')

@section('content')
        <img src="/img/logo.jpg" alt="LOGO ETEC">
        <h1>Categoria exibindo id:{{ $id }}</h1>
        <br>

        @if ($id != null)
                <p>Exibindo categoria no if id:{{ $id }}</p>
            
        @endif
        
@endsection