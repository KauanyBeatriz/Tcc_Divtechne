@extends('layouts.main')

@section('title', 'ETEC EVENTOS')

@section('content')

       <h1>3DSI DESENVOLVIMENTO DE SISTEMAS</h1>
       <img src="/img/logo.jpg" alt="LOGO ETEC">
       

@endsection