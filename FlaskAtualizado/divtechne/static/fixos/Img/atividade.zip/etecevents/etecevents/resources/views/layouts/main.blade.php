<!DOCTYPE html>
<html lang="PT-BR">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">


        <title>@yield('title')</title>

        <link rel="stylesheet" href="./css/styles.css">
        <script src="/js/scripts.js"></script>
    </head>
    <body>
        
    @yield('content')
        <footer>
            <p>ETEC EVENTOS &copy; 2023</p>
        </footer>
    </body>
</html>