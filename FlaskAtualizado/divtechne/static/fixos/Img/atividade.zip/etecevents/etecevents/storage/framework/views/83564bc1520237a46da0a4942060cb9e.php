

<?php $__env->startSection('title', 'Categoria'); ?>

<?php $__env->startSection('content'); ?>
        <img src="/img/logo.jpg" alt="LOGO ETEC">
        <h1>Categoria exibindo id:<?php echo e($id); ?></h1>
        <br>

        <?php if($id != null): ?>
                <p>Exibindo categoria no if id:<?php echo e($id); ?></p>
            
        <?php endif; ?>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kauan\Downloads\etecevents\etecevents\resources\views/categoria.blade.php ENDPATH**/ ?>