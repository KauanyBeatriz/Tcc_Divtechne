@extends('layouts.main')

@section('title', 'ETEC EVENTOS')

@section('content')

        <h1>TELA DOS PRODUTOS </h1>
        
        @IF($busca != '')
            <p> O usuário esta buscando produtos: {{$busca}}</p>
            
        @endif

@endsection