<!DOCTYPE html>
<html lang="PT-BR">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">


        <title>Projetinho</title>

        <link rel="stylesheet" href="styles.css"

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    </head>
    <body >
        <h1> TITULO ETEC COMPANY </h1>

    </body>
</html>
<?php /**PATH C:\Users\ETEC\Desktop\projeto\etecevents\resources\views/welcome.blade.php ENDPATH**/ ?>