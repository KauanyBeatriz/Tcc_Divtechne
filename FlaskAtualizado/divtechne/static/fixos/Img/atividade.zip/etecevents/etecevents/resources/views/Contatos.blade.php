@extends('layouts.main')

@section('title', 'Contatos')

@section('content')

        <h1>Contatos</h1>
        <br>
        <h4>FAQ 13 94253-7463</h4>
        <h4>Suport 13 95379-3267</h4>
        <h4>Ajuda 13 95376-8962</h4>
        
            
        @endif
        
@endsection